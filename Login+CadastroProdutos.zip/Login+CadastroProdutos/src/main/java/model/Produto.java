/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aluno.saolucas
 */
public class Produto {
    private int ID;
    private String NOME;
    private double PRECO;
    private int ESTOQUE;
    
    public Produto(String NOME, double PRECO, int ESTOQUE){
        this.NOME = NOME;
        this.PRECO = PRECO;
        this.ESTOQUE = ESTOQUE;
    }

    public int getID() {
        return ID;
    }

    public String getNOME() {
        return NOME;
    }

    public double getPRECO() {
        return PRECO;
    }

    public int getESTOQUE() {
        return ESTOQUE;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNOME(String NOME) {
        this.NOME = NOME;
    }

    public void setPRECO(double PRECO) {
        this.PRECO = PRECO;
    }

    public void setESTOQUE(int ESTOQUE) {
        this.ESTOQUE = ESTOQUE;
    }

}
