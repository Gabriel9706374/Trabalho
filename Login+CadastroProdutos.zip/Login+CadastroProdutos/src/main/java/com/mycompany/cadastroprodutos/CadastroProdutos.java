package com.mycompany.cadastroprodutos;

import dao.Conexao;
import view.TelaLogin;

public class CadastroProdutos {

    public static void main(String[] args) {
        Conexao.inicializarBanco();

        TelaLogin tela_login = new TelaLogin();
        tela_login.setVisible(true);
    }
}
