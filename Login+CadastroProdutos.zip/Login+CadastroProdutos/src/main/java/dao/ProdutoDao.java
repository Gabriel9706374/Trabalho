/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import model.Produto;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import dao.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno.saolucas
 */
public class ProdutoDao {
    public void cadastrar(Produto produto){
        String sql = "INSERT INTO produto(NOME, PRECO, ESTOQUE)VALUES(?,?,?)";
        
        try(Connection conexao = Conexao.conectar();
                PreparedStatement comando = conexao.prepareStatement(sql)){
                    comando.setString(1, produto.getNOME());
                    comando.setDouble(2, produto.getPRECO());
                    comando.setInt(3, produto.getESTOQUE());
                    comando.executeUpdate();
                    System.out.println("Produto cadastrado com sucesso!");
                }catch(SQLException e){
                        System.out.println("Erro ao cadastrar produto" + e.getMessage());
                    }
    }
    
     public List<Produto> listar() {

        List<Produto> produtos = new ArrayList<>();

        String sql = """
                     SELECT * FROM Produto;
                     """;

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql);
             ResultSet resultado = comando.executeQuery()) {

            while (resultado.next()) {

                Produto produto = new Produto(
                    resultado.getString("NOME"),
                    resultado.getDouble("PRECO"),
                    resultado.getInt("ESTOQUE")
                );

                produtos.add(produto);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
        return produtos;
     }
     
     public void excluir(int ID) {
         String sql = "DELETE FROM produto where id = ?";
         
         try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {
             
             comando.setInt(1, ID);
             comando.executeUpdate();

             System.out.println("Produto excluido com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro ao excluir produtos: " + e.getMessage());
        }
     }
     
     
     
     public void atualizar(Produto produto) {

        String sql = """
            UPDATE produto
            SET nome = ?, preco = ?, estoque = ?
            WHERE id = ?
            """;

        try (Connection conexao = Conexao.conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, produto.getNOME());
            comando.setDouble(2, produto.getPRECO());
            comando.setInt(3, produto.getESTOQUE());
            comando.setInt(4, produto.getID());

            comando.executeUpdate();

            System.out.println("Produto atualizado com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
        }
    }
     
}
