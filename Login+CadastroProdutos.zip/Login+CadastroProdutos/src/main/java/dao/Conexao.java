/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author aluno.saolucas
 */
public class Conexao {
    private static final String url = "jdbc:sqlite:CadastroProdutosBanco.db";
    
    public static Connection conectar() throws SQLException{
        return DriverManager.getConnection(url);
    } 
    public static void inicializarBanco(){
        String sql = "CREATE TABLE if not exists produto(ID INTEGER PRIMARY KEY AUTOINCREMENT, NOME TEXT NOT NULL, PRECO NUMBER NOT NULL, ESTOQUE INTEGER NOT NULL)";
        
        try(Connection conexao = conectar();
            Statement comando = conexao.createStatement()){
            comando.execute(sql);
            System.out.println("Banco SQLITE Conectado");
            System.out.println("Tabela Produto verificada!");
        }catch(SQLException e){
            System.out.println("Erro ao conectar." + e.getMessage());
        }
    }
}
